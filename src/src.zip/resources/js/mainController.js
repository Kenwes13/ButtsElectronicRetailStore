/**
 * Created by James on 10/14/2016.
 */
var app = angular.module('MyApp', []);
app.controller('MainController', function ($scope) {
        this.label = "Text Here";
});