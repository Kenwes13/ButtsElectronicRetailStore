<?php
$conn=mysqli_connect("localhost","root","!@)59380","ElectStore");
?>
